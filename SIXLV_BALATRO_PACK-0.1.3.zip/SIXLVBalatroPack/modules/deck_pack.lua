local CARTOMANCER_BACK_KEY = 'b_cartomancer_deck'
local INFERNO_BACK_KEY = 'b_cartomancer_inferno'
local ICEBOUND_HANDS_PER_DOLLAR = 2
local ICEBOUND_DOLLARS_PER_GROUP = 1
local INFERNO_HAND_SIZE_BONUS = 4
local INFERNO_ANTE_OFFSET = 2
local INFERNO_FIRST_HAND_LEVELS = 2
local INFERNO_ANTE_TEN_MULTIPLIER = 2.5
local INFERNO_WIN_ANTE = 10

local INFERNO_STARTING_JOKERS = {
    'j_greedy_joker',
    'j_lusty_joker',
    'j_wrathful_joker',
    'j_gluttenous_joker',
}

local ENHANCED_MAX_HIGHLIGHTED = {
    c_magician = 3,
    c_empress = 3,
    c_heirophant = 3,
    c_lovers = 2,
    c_chariot = 2,
    c_justice = 2,
    c_strength = 4,
    c_hanged_man = 3,
    c_devil = 2,
    c_tower = 2,
    c_star = 4,
    c_moon = 4,
    c_sun = 4,
    c_world = 4,
}

-- Vanilla values are only a final UI fallback. In particular, Steamodded also
-- takes ownership of Strength and its SMODS object may not expose the original
-- center config through self.config even though the actual card still has it.
local VANILLA_MAX_HIGHLIGHTED = {
    c_magician = 2,
    c_empress = 2,
    c_heirophant = 2,
    c_lovers = 1,
    c_chariot = 1,
    c_justice = 1,
    c_strength = 2,
    c_hanged_man = 2,
    c_devil = 1,
    c_tower = 1,
    c_star = 3,
    c_moon = 3,
    c_sun = 3,
    c_world = 3,
}

local CARTOMANCER_SHOP_RATES = {
    joker = 20,
    tarot = 4,
    planet = 0,
}

local CARTOMANCER_BOOSTER_WEIGHT_MULTIPLIERS = {
    Standard = 1.5,
    Spectral = 2,
}

local CARTOMANCER_CERTIFICATE_SEALS = {
    'Red',
    'Gold',
    'Purple',
}

local JUDGEMENT_BASE_COST = 5
local BLACK_HOLE_KEY = 'c_black_hole'

local ENHANCED_EXTRA = {
    c_hermit = 30,
    c_wheel_of_fortune = 3,
    c_temperance = 80,
}

local PLANET_VOUCHERS = {
    v_planet_merchant = true,
    v_planet_tycoon = true,
    v_telescope = true,
    v_observatory = true,
}

local BLOCKED_PLANET_SOURCE_KEYS = {
    [BLACK_HOLE_KEY] = true,
    c_trance = true,
    tag_meteor = true,
}

local function is_cartomancer_run()
    if not (G and G.GAME) then return false end

    if G.GAME.modifiers and G.GAME.modifiers.cartomancer_tarots then
        return true
    end

    local selected_back = G.GAME.selected_back
    return selected_back
        and selected_back.effect
        and selected_back.effect.center
        and selected_back.effect.center.key == CARTOMANCER_BACK_KEY
end

local function is_inferno_run()
    if not (G and G.GAME) then return false end

    if G.GAME.modifiers and G.GAME.modifiers.inferno_deck then
        return true
    end

    local selected_back = G.GAME.selected_back
    return selected_back
        and selected_back.effect
        and selected_back.effect.center
        and selected_back.effect.center.key == INFERNO_BACK_KEY
end

local function current_center_key(card, fallback)
    local center = fallback or (card and card.config and card.config.center)
    return center and center.key
end

local function is_blocked_planet_source(prototype)
    if not prototype then return false end

    if prototype.set == 'Planet' then return true end
    if prototype.set == 'Booster' and prototype.kind == 'Celestial' then return true end

    local key = prototype.key
    if not key then return false end

    return BLOCKED_PLANET_SOURCE_KEYS[key]
        or PLANET_VOUCHERS[key]
        or key:match('^p_celestial_') ~= nil
end

-- Keep global hooks idempotent across Steamodded reloads. Every installed hook
-- reads the current callbacks and configuration from this shared state, so a
-- reload updates behaviour without wrapping the same function a second time.
local HOOK_STATE_KEY = '__cartomancer_deck_hook_state'
local HOOK_STATE = rawget(_G, HOOK_STATE_KEY)
if not HOOK_STATE then
    HOOK_STATE = {
        originals = {},
        tarot_originals = {},
    }
    rawset(_G, HOOK_STATE_KEY, HOOK_STATE)
end

HOOK_STATE.is_cartomancer_run = is_cartomancer_run
HOOK_STATE.is_inferno_run = is_inferno_run
HOOK_STATE.current_center_key = current_center_key
HOOK_STATE.is_blocked_planet_source = is_blocked_planet_source
HOOK_STATE.enhanced_max_highlighted = ENHANCED_MAX_HIGHLIGHTED
HOOK_STATE.enhanced_extra = ENHANCED_EXTRA
HOOK_STATE.booster_weight_multipliers = CARTOMANCER_BOOSTER_WEIGHT_MULTIPLIERS
HOOK_STATE.planet_vouchers = PLANET_VOUCHERS
HOOK_STATE.judgement_base_cost = JUDGEMENT_BASE_COST
HOOK_STATE.black_hole_key = BLACK_HOLE_KEY
HOOK_STATE.inferno_ante_ten_multiplier = INFERNO_ANTE_TEN_MULTIPLIER

-- Install after every run begins rather than immediately at mod load. This
-- captures the final get_blind_amount implementation after other mods (such as
-- Bulky Stakes) have wrapped it, regardless of their relative load order.
local function install_inferno_blind_amount_hook()
    if get_blind_amount == HOOK_STATE.inferno_blind_amount_wrapper then return end

    local base_get_blind_amount = get_blind_amount
    local wrapper = function(ante)
        if HOOK_STATE.is_inferno_run() and ante == INFERNO_WIN_ANTE then
            return base_get_blind_amount(ante - 1)
                * HOOK_STATE.inferno_ante_ten_multiplier
        end
        return base_get_blind_amount(ante)
    end

    HOOK_STATE.inferno_blind_amount_wrapper = wrapper
    get_blind_amount = wrapper
end

HOOK_STATE.install_inferno_blind_amount_hook = install_inferno_blind_amount_hook

if not HOOK_STATE.originals.game_start_run then
    HOOK_STATE.originals.game_start_run = Game.start_run
    function Game:start_run(args)
        HOOK_STATE.install_inferno_blind_amount_hook()
        return HOOK_STATE.originals.game_start_run(self, args)
    end
end

SMODS.Atlas {
    key = 'back',
    path = 'cartomancer_back.png',
    px = 71,
    py = 95,
}

SMODS.Atlas {
    key = 'icebound_back',
    path = 'icebound_back.png',
    px = 71,
    py = 95,
}

SMODS.Atlas {
    key = 'inferno_back',
    path = 'inferno_back.png',
    px = 71,
    py = 95,
}

SMODS.Back {
    key = 'deck',
    atlas = 'back',
    pos = { x = 0, y = 0 },
    config = {},
    -- Back.loc_vars is called with only self in Steamodded 1.0.0~BETA-1814a.
    loc_vars = function(self)
        return { vars = {} }
    end,
    apply = function(self)
        G.GAME.modifiers = G.GAME.modifiers or {}
        G.GAME.modifiers.cartomancer_tarots = true
        G.GAME.joker_rate = CARTOMANCER_SHOP_RATES.joker
        G.GAME.tarot_rate = CARTOMANCER_SHOP_RATES.tarot
        G.GAME.planet_rate = CARTOMANCER_SHOP_RATES.planet
    end,
}

local function icebound_cashout()
    local hands_left = G
        and G.GAME
        and G.GAME.current_round
        and G.GAME.current_round.hands_left
        or 0
    local payout = math.floor(hands_left / ICEBOUND_HANDS_PER_DOLLAR)
        * ICEBOUND_DOLLARS_PER_GROUP
    return hands_left, payout
end

SMODS.Back {
    key = 'icebound',
    atlas = 'icebound_back',
    pos = { x = 0, y = 0 },
    config = {
        hands = 2,
        starting_discards = 0,
    },
    loc_vars = function(self)
        return {
            vars = {
                self.config.hands,
                self.config.starting_discards,
                ICEBOUND_HANDS_PER_DOLLAR,
                ICEBOUND_DOLLARS_PER_GROUP,
            },
        }
    end,
    apply = function(self)
        -- The vanilla Blue Stake penalty is applied before the selected Back.
        -- Clamp the starting value here so the deck always begins at exactly
        -- zero discards, while Wasteful and Recyclomancy can restore them later.
        G.GAME.starting_params.discards = self.config.starting_discards
        G.GAME.modifiers = G.GAME.modifiers or {}
        G.GAME.modifiers.no_extra_hand_money = true
    end,
    calculate = function(self, back, context)
        if not context or context.context ~= 'eval' then return end

        local hands_left, payout = icebound_cashout()
        if payout <= 0 then return end

        -- Use the same number-plus-label layout as the vanilla remaining-hands
        -- row, but omit the misleading "$1 each" suffix. The actual dollars
        -- on the right are still floor(hands_left / 2).
        add_round_eval_row {
            dollars = payout,
            bonus = true,
            name = 'custom_icebound_hands',
            pitch = 1,
            number = hands_left,
            number_colour = G.C.BLUE,
            number_scale = 0.8,
            text = localize('s1xlv_icebound_remaining_hands'),
            text_colour = G.C.UI.TEXT_LIGHT,
            text_scale = 0.4,
        }
    end,
    calc_dollar_bonus = function(self)
        local _, payout = icebound_cashout()
        if payout <= 0 then return end

        return payout, {
            no_eval_row = true,
        }
    end,
}

local function remove_starting_joker_extras(card)
    if not card then return end

    -- add_joker normally creates a base-edition card, but explicitly clear an
    -- edition in case another loaded mod decorates cards during construction.
    if card.edition and card.set_edition then
        card:set_edition(nil, true, true)
    end

    -- Remove every registered Sticker, including Eternal, Perishable, Rental,
    -- and third-party Stickers such as Bulky. Using each Sticker's own removal
    -- callback also reverses any slot/passive side effects it may have applied.
    if SMODS and SMODS.Sticker and SMODS.Sticker.obj_buffer
        and card.remove_sticker then
        for _, sticker_key in ipairs(SMODS.Sticker.obj_buffer) do
            card:remove_sticker(sticker_key)
        end
    end

    -- Keep the four starting instances plain even if an older Sticker API or
    -- another mod stores the vanilla flags directly on Card.ability.
    if card.ability then
        card.ability.eternal = nil
        card.ability.perishable = nil
        card.ability.perish_tally = nil
        card.ability.rental = nil
    end
    card.pinned = nil

    if card.set_cost then card:set_cost() end
end

local function add_inferno_starting_jokers()
    for index, center_key in ipairs(INFERNO_STARTING_JOKERS) do
        local card = add_joker(center_key, nil, index ~= 1)
        remove_starting_joker_extras(card)
    end
end

SMODS.Back {
    key = 'inferno',
    atlas = 'inferno_back',
    pos = { x = 0, y = 0 },
    config = {
        hand_size = INFERNO_HAND_SIZE_BONUS,
        ante = INFERNO_ANTE_OFFSET,
    },
    loc_vars = function(self)
        return {
            vars = {
                self.config.hand_size,
                self.config.ante,
                localize { type = 'name_text', set = 'Joker', key = INFERNO_STARTING_JOKERS[1] },
                localize { type = 'name_text', set = 'Joker', key = INFERNO_STARTING_JOKERS[2] },
                localize { type = 'name_text', set = 'Joker', key = INFERNO_STARTING_JOKERS[3] },
                localize { type = 'name_text', set = 'Joker', key = INFERNO_STARTING_JOKERS[4] },
                INFERNO_FIRST_HAND_LEVELS,
            },
        }
    end,
    apply = function(self)
        G.GAME.modifiers = G.GAME.modifiers or {}
        G.GAME.modifiers.inferno_deck = true

        -- Start two Antes later while still playing eight complete Antes.
        -- win_ante = 10 makes Ante 8 a normal Boss and reserves the vanilla
        -- showdown Boss pool for Ante 10 through get_new_boss().
        local starting_ante = 1 + self.config.ante
        G.GAME.round_resets.ante = starting_ante
        G.GAME.round_resets.blind_ante = starting_ante
        G.GAME.win_ante = INFERNO_WIN_ANTE

        -- Vanilla consumes this value immediately before reading the first
        -- played hand's base Chips and Mult, so that first hand also benefits.
        G.GAME.first_used_hand_level =
            (G.GAME.first_used_hand_level or 0) + INFERNO_FIRST_HAND_LEVELS

        -- Queue creation until G.jokers exists. add_joker bypasses the normal
        -- create_card Sticker rolls; the cleanup is a second compatibility
        -- guard for mods that decorate cards through other constructors.
        delay(0.4)
        G.E_MANAGER:add_event(Event {
            func = function()
                add_inferno_starting_jokers()
                return true
            end,
        })
    end,
}

-- Keep enhanced values on each Tarot instance. Vanilla stores center.config by
-- reference in ability.consumeable, so copying first prevents this deck from
-- changing Tarot cards in other runs or the collection.
if not HOOK_STATE.originals.card_set_ability then
    HOOK_STATE.originals.card_set_ability = Card.set_ability
    function Card:set_ability(center, initial, delay_sprites)
        local result = HOOK_STATE.originals.card_set_ability(self, center, initial, delay_sprites)
        local applied_center = (self.config and self.config.center) or center
        local key = HOOK_STATE.current_center_key(self, applied_center)

        if HOOK_STATE.is_cartomancer_run()
            and applied_center
            and applied_center.set == 'Tarot'
            and self.ability
            and self.ability.consumeable then
            self.ability.consumeable = copy_table(self.ability.consumeable)

            local max_highlighted = HOOK_STATE.enhanced_max_highlighted[key]
            if max_highlighted then
                self.ability.consumeable.max_highlighted = max_highlighted
                self.ability.consumeable.mod_num = max_highlighted
            end

            local extra = HOOK_STATE.enhanced_extra[key]
            if extra then
                self.ability.extra = extra
                self.ability.consumeable.extra = extra
            end

            if key == 'c_judgement' then
                self.base_cost = HOOK_STATE.judgement_base_cost
            end
        end

        return result
    end
end

-- Planet cards, Black Hole, and every vanilla source dedicated to obtaining
-- Planet cards are kept out of pools while this deck is active. Other direct
-- hand-level upgrades remain valid because they do not create Planet cards.
if not HOOK_STATE.originals.add_to_pool then
    HOOK_STATE.originals.add_to_pool = SMODS.add_to_pool
    function SMODS.add_to_pool(prototype, args)
        if HOOK_STATE.is_cartomancer_run()
            and HOOK_STATE.is_blocked_planet_source(prototype) then
            return false
        end
        return HOOK_STATE.originals.add_to_pool(prototype, args)
    end
end

-- Booster packs use prototype weights rather than the loose-card shop rates.
-- Apply the deck's Standard/Spectral multipliers only for the duration of a
-- pack roll, then restore every prototype so other decks remain unchanged.
local function multiplied_weight_getter(original_get_weight, multiplier)
    return function(self, ...)
        return (original_get_weight(self, ...) or 0) * multiplier
    end
end

if not HOOK_STATE.originals.get_pack then
    HOOK_STATE.originals.get_pack = get_pack
    function get_pack(_key, _type)
        local booster_pool = G
            and G.P_CENTER_POOLS
            and G.P_CENTER_POOLS.Booster

        if not HOOK_STATE.is_cartomancer_run() or not booster_pool then
            return HOOK_STATE.originals.get_pack(_key, _type)
        end

        local changed_weights = {}
        for _, booster in ipairs(booster_pool) do
            local multiplier = HOOK_STATE.booster_weight_multipliers[booster.kind]
            if multiplier then
                changed_weights[#changed_weights + 1] = {
                    booster = booster,
                    weight = booster.weight,
                    get_weight = booster.get_weight,
                }
                if booster.get_weight then
                    booster.get_weight = multiplied_weight_getter(booster.get_weight, multiplier)
                else
                    booster.weight = (booster.weight or 1) * multiplier
                end
            end
        end

        local ok, pack_or_error = pcall(HOOK_STATE.originals.get_pack, _key, _type)

        for _, changed in ipairs(changed_weights) do
            changed.booster.weight = changed.weight
            changed.booster.get_weight = changed.get_weight
        end

        if not ok then error(pack_or_error, 0) end
        return pack_or_error
    end
end

-- A forced Planet Merchant/Tycoon from another mod must not restore the shop's
-- Planet rate. Natural copies of these vouchers are already filtered above.
if not HOOK_STATE.originals.card_apply_to_run then
    HOOK_STATE.originals.card_apply_to_run = Card.apply_to_run
    function Card:apply_to_run(center)
        local key = HOOK_STATE.current_center_key(self, center)
        if HOOK_STATE.is_cartomancer_run() and HOOK_STATE.planet_vouchers[key] then
            G.GAME.planet_rate = 0
            return
        end

        local result = HOOK_STATE.originals.card_apply_to_run(self, center)
        if HOOK_STATE.is_cartomancer_run() then G.GAME.planet_rate = 0 end
        return result
    end
end

-- Normal seal rolls may not produce Blue in Cartomancer runs. Direct calls to
-- Card:set_seal remain untouched, so a cheated Trance or Blue Seal still works.
if not HOOK_STATE.originals.poll_seal then
    HOOK_STATE.originals.poll_seal = SMODS.poll_seal
    function SMODS.poll_seal(args)
        if not HOOK_STATE.is_cartomancer_run() then
            return HOOK_STATE.originals.poll_seal(args)
        end

        local blue_seal = G and G.P_SEALS and G.P_SEALS.Blue
        if not blue_seal then return HOOK_STATE.originals.poll_seal(args) end

        local original_weight = blue_seal.weight
        local original_get_weight = blue_seal.get_weight
        blue_seal.weight = 0
        blue_seal.get_weight = function() return 0 end

        local ok, seal_or_error = pcall(HOOK_STATE.originals.poll_seal, args or {})

        blue_seal.weight = original_weight
        blue_seal.get_weight = original_get_weight

        if not ok then error(seal_or_error, 0) end
        return seal_or_error
    end
end

-- Vanilla chooses Black Hole as an internal forced key after pool filtering.
-- Ban it only during an unforced random Planet/Spectral roll. An explicit
-- forced key (for example from a cheat console) bypasses this temporary ban.
-- Balatro Balance Patch 0.3.12 restores Illusion's seal finish with direct
-- Card:set_seal calls, so it intentionally bypasses SMODS.poll_seal. Inspect
-- only cards returned by the natural shop-card generator: if Illusion rolled
-- Blue in a Cartomancer run, redistribute that result equally among the three
-- permitted seals. Direct/cheated Card:set_seal('Blue') calls elsewhere remain
-- untouched.
if not HOOK_STATE.originals.create_card_for_shop then
    HOOK_STATE.originals.create_card_for_shop = create_card_for_shop
    function create_card_for_shop(area)
        local card = HOOK_STATE.originals.create_card_for_shop(area)
        local ability_set = card and card.ability and card.ability.set
        local is_shop_playing_card = ability_set == 'Default' or ability_set == 'Enhanced'
        local illusion_active = G and G.GAME and G.GAME.used_vouchers
            and G.GAME.used_vouchers.v_illusion

        if HOOK_STATE.is_cartomancer_run()
            and illusion_active
            and is_shop_playing_card
            and card.seal == 'Blue' then
            local ante = G.GAME.round_resets and G.GAME.round_resets.ante or 0
            local replacement = pseudorandom_element(
                CARTOMANCER_CERTIFICATE_SEALS,
                pseudoseed('cartomancer_illusion_seal' .. ante)
            )
            card:set_seal(replacement, true, true)
        end

        return card
    end
end

if not HOOK_STATE.originals.create_card then
    HOOK_STATE.originals.create_card = create_card
    function create_card(_type, area, legendary, _rarity, skip_materialize, soulable, forced_key, key_append)
        local should_filter_black_hole = HOOK_STATE.is_cartomancer_run()
            and soulable
            and not forced_key
            and (_type == 'Planet' or _type == 'Spectral')

        if not should_filter_black_hole then
            return HOOK_STATE.originals.create_card(
                _type, area, legendary, _rarity, skip_materialize,
                soulable, forced_key, key_append
            )
        end

        G.GAME.banned_keys = G.GAME.banned_keys or {}
        local previous_ban = G.GAME.banned_keys[HOOK_STATE.black_hole_key]
        G.GAME.banned_keys[HOOK_STATE.black_hole_key] = true

        local ok, card_or_error = pcall(
            HOOK_STATE.originals.create_card,
            _type, area, legendary, _rarity, skip_materialize,
            soulable, forced_key, key_append
        )

        G.GAME.banned_keys[HOOK_STATE.black_hole_key] = previous_ban

        if not ok then error(card_or_error, 0) end
        return card_or_error
    end
end

-- Vanilla Certificate chooses equally from four seals and only calls
-- Card:set_seal afterwards. Dropping Blue there would create an unsealed card,
-- so replace Certificate's roll in Cartomancer runs with a three-seal pool.
-- All three remaining seals therefore have an exact 1/3 selection weight.
if not HOOK_STATE.certificate_original_captured then
    HOOK_STATE.certificate_original_calculate = G.P_CENTERS.j_certificate.calculate
    HOOK_STATE.certificate_original_captured = true
end

local certificate = SMODS.Joker:take_ownership('certificate', {
    calculate = function(self, card, context)
        if not is_cartomancer_run() then
            local original = HOOK_STATE.certificate_original_calculate
            if original then return original(self, card, context) end
            return
        end
        if not context.first_hand_drawn then return end

        G.E_MANAGER:add_event(Event {
            func = function()
                local generated_card = create_playing_card({
                    front = pseudorandom_element(G.P_CARDS, pseudoseed('cert_fr')),
                    center = G.P_CENTERS.c_base,
                }, G.hand, nil, nil, { G.C.SECONDARY_SET.Enhanced })

                local seal = pseudorandom_element(
                    CARTOMANCER_CERTIFICATE_SEALS,
                    pseudoseed('certsl')
                )
                generated_card:set_seal(seal, nil, true)
                G.GAME.blind:debuff_card(generated_card)
                G.hand:sort()

                if context.blueprint_card then
                    context.blueprint_card:juice_up()
                else
                    card:juice_up()
                end
                playing_card_joker_effects({ generated_card })
                save_run()
                return true
            end,
        })

        return nil, true
    end,
}, true)
assert(certificate, '[Cartomancer Deck] Could not take ownership of j_certificate')

local function take_tarot(key, definition)
    local center_key = 'c_' .. key
    local originals = HOOK_STATE.tarot_originals[center_key]
    if not originals then
        originals = {}
        local current = G.P_CENTERS[center_key]
        for field, value in pairs(definition) do
            if type(value) == 'function' then
                -- Preserve only a method explicitly installed on this center.
                -- Steamodded-owned consumables inherit Consumable.loc_vars,
                -- whose default implementation returns an empty table. Strength
                -- is owned internally by Steamodded, so normal table lookup
                -- captured that inherited no-op and produced #1# = nil outside
                -- Cartomancer runs. rawget still preserves real earlier-mod
                -- overrides while ignoring class defaults.
                originals[field] = current and rawget(current, field)
            end
        end
        HOOK_STATE.tarot_originals[center_key] = originals
    end

    local scoped_definition = {}
    for field, value in pairs(definition) do
        if type(value) == 'function' then
            local cartomancer_function = value
            local original_function = originals[field]
            scoped_definition[field] = function(self, ...)
                if HOOK_STATE.is_cartomancer_run() then
                    return cartomancer_function(self, ...)
                end
                if original_function then
                    return original_function(self, ...)
                end
                -- Vanilla centers often have no SMODS method to delegate to.
                -- In that case the supplied function's non-Cartomancer branch
                -- reproduces the current vanilla behaviour.
                return cartomancer_function(self, ...)
            end
        else
            scoped_definition[field] = value
        end
    end

    local owned = SMODS.Consumable:take_ownership(key, scoped_definition, true)
    assert(owned, ('[Cartomancer Deck] Could not take ownership of c_%s'):format(key))
    return owned
end

local function displayed_max(self, card)
    local key = self.key
    if is_cartomancer_run() and ENHANCED_MAX_HIGHLIGHTED[key] then
        return ENHANCED_MAX_HIGHLIGHTED[key]
    end

    -- Steamodded flattens center.config into Card.ability for real and fake UI
    -- cards. Strength is also owned internally by Steamodded, so its loc_vars
    -- self.config can be empty while card.ability.max_highlighted is still 2.
    local ability = card and card.ability
    if ability and ability.max_highlighted ~= nil then
        return ability.max_highlighted
    end
    if ability and ability.consumeable
        and ability.consumeable.max_highlighted ~= nil then
        return ability.consumeable.max_highlighted
    end

    local registered_center = G and G.P_CENTERS and G.P_CENTERS[key]
    if registered_center and registered_center.config
        and registered_center.config.max_highlighted ~= nil then
        return registered_center.config.max_highlighted
    end
    if self.config and self.config.max_highlighted ~= nil then
        return self.config.max_highlighted
    end
    return VANILLA_MAX_HIGHLIGHTED[key]
end

local function displayed_extra(self)
    if is_cartomancer_run() and ENHANCED_EXTRA[self.key] then
        return ENHANCED_EXTRA[self.key]
    end
    -- The center config is the authoritative vanilla value in other decks and
    -- cannot retain a per-card value from the previous run's UI object.
    return self.config.extra
end

local function enhancement_loc_vars(self, info_queue, card)
    info_queue[#info_queue + 1] = G.P_CENTERS[self.config.mod_conv]
    return {
        vars = {
            displayed_max(self, card),
            localize { type = 'name_text', set = 'Enhanced', key = self.config.mod_conv },
        },
    }
end

for _, key in ipairs {
    'magician',
    'empress',
    'heirophant',
    'lovers',
    'chariot',
    'justice',
    'devil',
    'tower',
} do
    take_tarot(key, { loc_vars = enhancement_loc_vars })
end

local function highlighted_count_loc_vars(self, info_queue, card)
    return { vars = { displayed_max(self, card) } }
end

take_tarot('strength', { loc_vars = highlighted_count_loc_vars })
take_tarot('hanged_man', { loc_vars = highlighted_count_loc_vars })
take_tarot('hermit', {
    loc_vars = function(self, info_queue, card)
        return { vars = { displayed_extra(self, card) } }
    end,
})

take_tarot('wheel_of_fortune', {
    loc_vars = function(self, info_queue, card)
        info_queue[#info_queue + 1] = G.P_CENTERS.e_foil
        info_queue[#info_queue + 1] = G.P_CENTERS.e_holo
        info_queue[#info_queue + 1] = G.P_CENTERS.e_polychrome
        return { vars = { G.GAME.probabilities.normal, displayed_extra(self, card) } }
    end,
})

take_tarot('temperance', {
    loc_vars = function(self, info_queue, card)
        local cap = displayed_extra(self, card)
        local payout = 0
        if G.jokers and G.jokers.cards then
            for _, joker in ipairs(G.jokers.cards) do
                if joker.ability.set == 'Joker' then payout = payout + joker.sell_cost end
            end
        end
        return { vars = { cap, math.min(cap, payout) } }
    end,
})

local function suit_loc_vars(self, info_queue, card)
    return {
        vars = {
            displayed_max(self, card),
            localize(self.config.suit_conv, 'suits_plural'),
            colours = { G.C.SUITS[self.config.suit_conv] },
        },
    }
end

for _, key in ipairs { 'star', 'moon', 'sun', 'world' } do
    take_tarot(key, { loc_vars = suit_loc_vars })
end

local function can_level_last_hand()
    local hand = G and G.GAME and G.GAME.last_hand_played
    return hand ~= nil and G.GAME.hands and G.GAME.hands[hand] ~= nil
end

take_tarot('high_priestess', {
    loc_vars = function(self)
        if is_cartomancer_run() then
            return { key = 'c_cartomancer_high_priestess', vars = { 2 } }
        end
        return { vars = { self.config.planets } }
    end,
    can_use = function(self, card)
        if is_cartomancer_run() then return can_level_last_hand() end
        return G.consumeables
            and (#G.consumeables.cards < G.consumeables.config.card_limit or card.area == G.consumeables)
    end,
    use = function(self, card)
        if is_cartomancer_run() then
            local hand = G.GAME.last_hand_played
            if not can_level_last_hand() then return end
            SMODS.smart_level_up_hand(card, hand, nil, 2)
            return
        end

        local planet_count = card.ability.consumeable.planets or self.config.planets
        local count = math.min(planet_count, G.consumeables.config.card_limit - #G.consumeables.cards)
        for _ = 1, count do
            G.E_MANAGER:add_event(Event {
                trigger = 'after',
                delay = 0.4,
                func = function()
                    if G.consumeables.config.card_limit > #G.consumeables.cards then
                        play_sound('timpani')
                        local planet = create_card('Planet', G.consumeables, nil, nil, nil, nil, nil, 'pri')
                        planet:add_to_deck()
                        G.consumeables:emplace(planet)
                        card:juice_up(0.3, 0.5)
                    end
                    return true
                end,
            })
        end
        delay(0.6)
    end,
})

local function available_joker_slots()
    if not (G and G.GAME and G.jokers and G.jokers.cards and G.jokers.config) then return 0 end
    local occupied = #G.jokers.cards + (G.GAME.joker_buffer or 0)
    return math.max(0, G.jokers.config.card_limit - occupied)
end

take_tarot('judgement', {
    loc_vars = function(self)
        if is_cartomancer_run() then
            return { key = 'c_cartomancer_judgement', vars = { 2 } }
        end
        return { vars = {} }
    end,
    can_use = function(self, card)
        if is_cartomancer_run() then return available_joker_slots() > 0 end
        return G.jokers
            and (#G.jokers.cards < G.jokers.config.card_limit or card.area == G.jokers)
    end,
    use = function(self, card)
        if not is_cartomancer_run() then
            G.E_MANAGER:add_event(Event {
                trigger = 'after',
                delay = 0.4,
                func = function()
                    play_sound('timpani')
                    local joker = create_card('Joker', G.jokers, nil, nil, nil, nil, nil, 'jud')
                    joker:add_to_deck()
                    G.jokers:emplace(joker)
                    card:juice_up(0.3, 0.5)
                    return true
                end,
            })
            delay(0.6)
            return
        end

        local count = math.min(2, available_joker_slots())
        if count <= 0 then return end

        -- Reserve every slot before the delayed event. This is what makes the
        -- 0/1/2-slot cases deterministic and prevents simultaneous effects from
        -- overfilling the Joker area.
        G.GAME.joker_buffer = (G.GAME.joker_buffer or 0) + count
        G.E_MANAGER:add_event(Event {
            trigger = 'after',
            delay = 0.4,
            func = function()
                play_sound('timpani')
                for _ = 1, count do
                    if #G.jokers.cards < G.jokers.config.card_limit then
                        local joker = create_card('Joker', G.jokers, nil, nil, nil, nil, nil, 'jud')
                        joker:add_to_deck()
                        G.jokers:emplace(joker)
                        joker:start_materialize()
                    end
                end
                G.GAME.joker_buffer = math.max(0, (G.GAME.joker_buffer or count) - count)
                card:juice_up(0.3, 0.5)
                return true
            end,
        })
        delay(0.6)
    end,
})
